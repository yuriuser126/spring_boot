package com.boot.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.boot.dto.EmpDeptDTO;


public interface EmpDeptDAO {
	public ArrayList<EmpDeptDTO> list();
	
	
}















