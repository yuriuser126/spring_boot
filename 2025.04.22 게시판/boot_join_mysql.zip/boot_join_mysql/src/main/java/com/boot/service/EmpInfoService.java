package com.boot.service;

import java.util.ArrayList;

import com.boot.dto.EmpDeptDTO;

public interface EmpInfoService {
	public ArrayList<EmpDeptDTO> list();
}
