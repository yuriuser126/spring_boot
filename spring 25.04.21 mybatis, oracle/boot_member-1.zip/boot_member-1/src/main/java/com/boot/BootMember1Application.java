package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMember1Application {

	public static void main(String[] args) {
		SpringApplication.run(BootMember1Application.class, args);
	}

}
