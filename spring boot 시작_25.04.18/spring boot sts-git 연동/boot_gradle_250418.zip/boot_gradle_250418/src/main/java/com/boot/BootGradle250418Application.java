package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootGradle250418Application {

	public static void main(String[] args) {
		SpringApplication.run(BootGradle250418Application.class, args);
	}

}
