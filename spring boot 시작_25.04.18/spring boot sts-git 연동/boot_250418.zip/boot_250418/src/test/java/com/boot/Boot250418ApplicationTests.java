package com.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot250418ApplicationTests {

	@Test
	void contextLoads() {
	}

}
